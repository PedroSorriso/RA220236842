class Node{
  constructor(data){
    this.data = data;
    this.next = next;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.size = 0;
  }

  add(value) {
    const newNode = new Node(value);
    if (this.head === null) {
      this.head = newNode;
    } else {
      let current = this.head;
      while (current.next !== null) {
        current = current.next;
      }
      current.next = newNode;
    }
    this.size++;
  }
  
  insertAt(value, index) {
    if (index < 0 || index > this.size) {
      return console.log("Index out of range");
    }
    const newNode = new Node(value);
    let current = this.head;
    let previous = null;
    if (index === 0) {
      newNode.next = this.head;
      this.head = newNode;
    } else {
      for (let i = 0; i < index; i++) {
        previous = current;
        current = current.next;
      }
      newNode.next = current;
      previous.next = newNode;
    }
    this.size++;
  }

  removeFrom(index) {
    if (index < 0 || index >= this.size) {
      return console.log("Index out of range");
    }
    let current = this.head;
    let previous = null;
    if (index === 0) {
      this.head = current.next;
    } else {
      for (let i = 0; i < index; i++) {
        previous = current;
        current = current.next;
      }
      previous.next = current.next;
    }
    this.size--;
    return current.value;
  }

  removeValue(value) {
    let current = this.head;
    let previous = null;
    while (current !== null) {
      if (current.value === value) {
        if (previous === null) {
          this.head = current.next;
        } else {
          previous.next = current.next;
        }
        this.size--;
        return current.value;
      }
      previous = current;
      current = current.next;
    }
    return null;
  }

  isEmpty() {
    return this.size === 0;
  }

  getSize() {
    return this.size;
  }

  printList() {
    let current = this.head;
    let listValues = [];
    while (current !== null) {
      listValues.push(current.value);
      current = current.next;
    }
    console.log(listValues.join(" -> "));
  }
}

const linkedList = new LinkedList();

linkedList.add(10);
linkedList.add(20);
linkedList.add(30);

linkedList.insertAt(15, 1);
linkedList.insertAt(5, 0);

linkedList.removeFrom(3);
linkedList.removeValue(5);

console.log("Tamanho da lista:", linkedList.getSize());

console.log("A lista está vazia?", linkedList.isEmpty());

linkedList.printList();